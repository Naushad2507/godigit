package com.nau.dao;

import java.util.List;

import com.nau.model.StudentDTO;

public interface StudentDAO {

	void saveStudent(StudentDTO... studentDTOs);

	//	public Object[] getAllStudents() {
	//		Object[] students = studentsList.toArray();
	//		return students;
	//	}
	List<StudentDTO> getAllStudents();

	boolean verifyRollNo(Integer rollNo);

}