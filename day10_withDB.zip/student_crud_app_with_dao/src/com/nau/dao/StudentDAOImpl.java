package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.nau.model.StudentDTO;
import com.nau.util.DBConnection;

public class StudentDAOImpl implements StudentDAO {

	private Connection connection = DBConnection.getConnection();

	private static int count = 4;
	private StudentDTO[] students = new StudentDTO[15];
	{
		students[0] = new StudentDTO(1, "Naushad", "Goa", "nau@gmial.com");
		students[1] = new StudentDTO(2, "Akhtar", "Pune", "akhtar@gmial.com");
		students[2] = new StudentDTO(3, "Rahul", "Kerala", "rahul@gmial.com");
		students[3] = new StudentDTO(4, "Akshay", "Latur", "akshay@gmial.com");
		students[4] = new StudentDTO(5, "Roshan", "Pune", "roshan@gmial.com");
	}
	private List<StudentDTO> studentsList;
	{
		studentsList = Arrays.asList(students);
	}

	@Override
	public void saveStudent(StudentDTO... studentDTOs) {
		String sql = "insert into students values(?,?,?,?)";

		// orm.save(studenDTOS);
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(studentsList);
		for (StudentDTO dto : studentDTOs) {
			try {
				ps.setInt(1, dto.getRollNo());
				ps.setString(2, dto.getName());
				ps.setString(3, dto.getCity());
				ps.setString(4, dto.getEmail());
				ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.out.println("in dao" + dto);
			// studentsList.add(dto);
			System.out.println(dto);
			if (studentDTOs != null) {
				// count++;
				// students[count] = dto;
			}
		}
		System.out.println("Total : " + studentsList.size() + " saved");
	}

//	public Object[] getAllStudents() {
//		Object[] students = studentsList.toArray();
//		return students;
//	}
	@Override
	public List<StudentDTO> getAllStudents() {

		List<StudentDTO> studentList = new ArrayList<>();

		String sql = "select * from students";

		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				studentList.add(new StudentDTO(
						rs.getInt(1), 
						rs.getString(2), 
						rs.getString(3), 
						rs.getString(4)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return studentList;
	}

	@Override
	public boolean verifyRollNo(Integer rollNo) {

		return true;
	}
}
