package com.nau.main;

import com.nau.dao.StudentDAOImpl;
import com.nau.service.StudentServiceImpl;
import com.nau.view.StudentView;

public class StudentManagementApplication {
	
	public static void main(String[] args) {
		
//		StudentDAO dao = new StudentDAOImpl();
//		StudentService service = new StudentServiceImpl(dao);
//		new StudentView(service);
		
		
		new StudentView(new StudentServiceImpl(new StudentDAOImpl()));
	}
}
