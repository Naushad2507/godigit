package com.nau.view;

import java.util.List;
import java.util.Scanner;

import com.nau.model.StudentDTO;
import com.nau.service.StudentService;
import com.nau.service.StudentServiceImpl;

public class StudentView {

	// StudentDTO , StudentEntity, StudentModel
	private Scanner scanner = new Scanner(System.in);

	private StudentService service ;

	public StudentView(StudentService service) {
		this.service = service;
		mainMenu();
	}

	private void mainMenu() {
		System.out.println("----- Main Menu -----");
		System.out.println("1. Add Student");
		System.out.println("2. View Student");
		System.out.println("3. View All Student");
		System.out.println("4. Update Student");
		System.out.println("5. Delete Student");
		System.out.println("6. Exit Application");
		System.out.println("Select Option from Menu : (1 - 6)");
		selectOption();
	}

	private void selectOption() {
		int selectedOption = scanner.nextInt();
		switch (selectedOption) {
		case 1: {
			addStudent();
			System.out.print("\033[H\033[2J");
			System.out.flush();
			mainMenu();
			break;
		}
		case 2: {
			viewStudent();
			break;
		}
		case 3: {
			viewAllStudent();
			mainMenu();
			break;
		}
		case 4: {
			deleteStudent();
			break;
		}
		case 5: {
			updateStudent();
			break;
		}
		case 6: {
			System.out.println("----------- Thanks For Using the App -----------");
			System.exit(0);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + selectedOption);
		}
	}

	private void updateStudent() {

	}

	private void deleteStudent() {

	}

	private void viewAllStudent() {
		System.out.println("-------- Student Record ----------");
		List<StudentDTO> dtos = service.getAllStudents();
		for (StudentDTO studentDTO : dtos) {

			System.out.println(studentDTO);

		}
		System.out.println("=====================================");

	}

	private void viewStudent() {

	}

	private void addStudent() {
		StudentDTO[] dto = new StudentDTO[5];
		int count = 0;
		String ans = "N";
		do {
			System.out.println("----- Add Student -----");
			System.out.println("Enter Roll No : ");
			Integer rollNo = scanner.nextInt();
			if(!service.verfifyRollNo(rollNo)) {
				System.out.println("Roll No : "  + rollNo + " already Exist");
				return;
			}
			scanner.nextLine();
			System.out.println("Enter Name : ");

			String name = scanner.nextLine();
			System.out.println("Enter City : ");

			String city = scanner.nextLine();
			System.out.println("Enter Email : ");

			String email = scanner.nextLine();
			StudentDTO student = new StudentDTO(rollNo, name, city, email);
			dto[count] = student;
			count++;

			System.out.println("Do you want to add more (Y/N): ");
			ans = scanner.next();

		} while (ans.equalsIgnoreCase("y"));
		service.addStudents(dto);
	}

}
