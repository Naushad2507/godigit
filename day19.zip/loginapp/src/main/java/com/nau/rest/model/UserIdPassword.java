package com.nau.rest.model;

import lombok.Data;

@Data
public class UserIdPassword {
	
	private Integer userId;
	private String password;

}
