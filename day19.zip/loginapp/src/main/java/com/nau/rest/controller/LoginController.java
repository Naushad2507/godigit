package com.nau.rest.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nau.rest.model.User;
import com.nau.rest.model.UserIdPassword;

import static java.lang.System.*;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("login")
@Slf4j
public class LoginController {
	
	@GetMapping(value="verifyuser")
	public User verifyUser(@RequestBody UserIdPassword idPassword) {
	//
		User  user = new User();
		user.setUserId(idPassword.getUserId());
		user.setPassword(idPassword.getPassword());
		user.setFirstName("Akshad");
		user.setLastName("Patil");
		user.setEmail("akshad@gmail.com");
		user.setMobileNumber("878787787");
		out.println(user);
		return user;
	}
	
	@PostMapping("adduser")
	public String addUser(User user ) {
		//
		return "User registered successfully";
	}
	
	@PutMapping(value="updateuser")
	public void updateUser(@RequestBody User user) {
		out.println(user);
	}
	
	@DeleteMapping("deleteuser/{userId}")
	public void deleteUser(@PathVariable Integer userId) {
		System.out.println(userId);
	}

}
