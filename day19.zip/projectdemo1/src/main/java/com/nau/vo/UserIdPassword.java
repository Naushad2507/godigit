package com.nau.vo;

import lombok.Data;

@Data
public class UserIdPassword {
	
	private Integer userId;
	private String password;

}
