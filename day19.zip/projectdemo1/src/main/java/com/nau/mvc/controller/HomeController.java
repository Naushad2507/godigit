package com.nau.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.nau.vo.UserIdPassword;
import com.nau.vo.UserVO;

@Controller
@RequestMapping("/home")
public class HomeController {
	
	@PostMapping
	@RequestMapping("verify")
	public ModelAndView verifyUser(@RequestBody UserIdPassword idPassword) {
		//view
		String url ="http://localhost:5555/login/verifyuser";
		RestTemplate restTemplate = new RestTemplate();
		UserVO s = restTemplate.getForObject(url, UserVO.class,idPassword.getUserId(),idPassword.getPassword());
		System.out.println(s);
		ModelAndView mv = new ModelAndView();
		mv.addObject("uname", s.getFirstName()+" "+s.getLastName());
		mv.setViewName("welcomepage");
		return mv;
		
	}
	
	@GetMapping
	//@RequestMapping("/")
	public String index() {
		return "index";
	}
	@GetMapping
	@RequestMapping("login")
	public String loginPage() {
		return "loginpage";
	}
	@GetMapping
	@RequestMapping("welcome")
	public String welcomePage() {
		return "welcomepage";
	}

}
