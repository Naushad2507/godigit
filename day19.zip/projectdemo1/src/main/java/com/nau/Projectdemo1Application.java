package com.nau;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
public class Projectdemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Projectdemo1Application.class, args);
	}

}
