package com.nau.rest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nau.rest.model.User;

@RestController
public class AController {
	
	@GetMapping("ma/{userId}/{password}")
	public String ma(@PathVariable Integer userId,@PathVariable String  password) {
		if(userId==10) {
			return "ma - Valid User " + userId + " with password " + password;  
		}
		return "A - ma - InValid User " + userId + " with password " + password; 
	}
	
	@RequestMapping("mb")
	public String mb(@RequestBody User user) {
		if(user.getUserId()==10) {
			return "mb - Valid User " + user.getUserId() + " with password " + user.getPassword();  
		}
		return "A- mb - InValid User " + user.getUserId() + " with password " + user.getPassword(); 
	}

}
