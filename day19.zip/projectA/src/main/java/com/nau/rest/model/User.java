package com.nau.rest.model;

import lombok.Data;

@Data
public class User {
	private Integer userId;
	private String  password;
}
