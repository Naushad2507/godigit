package com.nau.controller;

import org.springframework.boot.json.GsonJsonParser;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.nau.vo.UserVO;

@RestController
public class BController {
	
	
	@GetMapping("bc")
	public String calltoAComponent() {
		
		String url = "http://localhost:8080/m/123/abc";
		RestTemplate restTemplate = new RestTemplate();
//		ResponseEntity<String> res = restTemplate.getForEntity(url, String.class);
//		String r = res.getBody();
		
		String res2 = restTemplate.getForObject(url, String.class);
		
		return res2;
	}
	@GetMapping("bc2/")
	public String calltoAComponentmb() {
		
		String url = "http://localhost:8080/mb";
		RestTemplate restTemplate = new RestTemplate();
		UserVO vo = new UserVO(66,"popop");
		String res2 = restTemplate.postForObject(url, vo,String.class);
		
		return res2;
	}


}
