package com.nau;

import java.lang.reflect.InvocationTargetException;

interface Engineer {
	public String engineerType();
}

class Boy {

	private Engineer engineer;

	Boy(Engineer engineer) {
		this.engineer = engineer;
	}
	public String getEngType() {
		return engineer.engineerType();
	}

}

class MTech implements Engineer {
	@Override
	public String engineerType() {
		 return "Boy is Mtech";
	}
}

class BTech implements Engineer {
	@Override
	public String engineerType() {
		 return "Boy is BTech";
	}
}
class BE implements Engineer{
	@Override
	public String engineerType() {
		 return "Boy is BE Computer Science";
	}
}
public class Hello {

	public static void main(String[] args)
			throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException,
			NoSuchMethodException, SecurityException, ClassNotFoundException {
		
		Object obj = Class.forName(args[0]).getDeclaredConstructor().newInstance();
		Engineer engineer = (Engineer) obj;
		Boy boy = new Boy(engineer);
		System.out.println(boy.getEngType());
		

	}

}
