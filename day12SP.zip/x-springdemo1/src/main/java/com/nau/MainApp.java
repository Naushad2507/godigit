package com.nau;

import java.beans.beancontext.BeanContext;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {

		System.out.println("Start");
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
		//Hello h = applicationContext.getBean(Hello.class);
		Hello h1 = (Hello)applicationContext.getBean("hello1");
		Hello h2 = (Hello)applicationContext.getBean("hello2");
		//System.out.println(h);
//		Hello h = (Hello) obj;
		//h.setMessage("Message from Naushad");
		System.out.println(h1.getMessage());
	//	System.out.println(h.getMessage());

		System.out.println("End");

	}

}
