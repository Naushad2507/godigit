package com.nau;

import lombok.Data;

@Data
public class Hello {

	private String message;
	private static int count;

	public Hello() {
		System.out.println("Hello Object Created " + ++count);
	}
}
