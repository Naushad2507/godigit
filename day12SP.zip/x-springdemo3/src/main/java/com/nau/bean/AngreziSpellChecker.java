package com.nau.bean;

import org.springframework.stereotype.Component;

@Component("angrezi")
public class AngreziSpellChecker implements SpellChecker {

	public AngreziSpellChecker() {
		System.out.println("SpellChecker Object Created");
	}
 
	@Override
	public String checkWord(String word) {
		return "The word in Angrezi,  " + word + ", is ok";
	}

}
