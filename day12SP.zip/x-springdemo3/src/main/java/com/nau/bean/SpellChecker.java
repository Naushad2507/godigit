package com.nau.bean;

public interface SpellChecker {

	public String checkWord(String word);
}
