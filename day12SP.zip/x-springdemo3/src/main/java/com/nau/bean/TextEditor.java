package com.nau.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class TextEditor {

	
	@Autowired
	@Qualifier("angrezi")
	private SpellChecker spellChecker;

	public TextEditor() {
		System.out.println("TextEditor Object Created");
	}

	public String spellCheck(String word) {
		return spellChecker.checkWord(word);
	}

	
}
