package com.nau.bean;

import org.springframework.stereotype.Component;

@Component("hindi")
public class HindiSpellChecker implements SpellChecker {

	public HindiSpellChecker() {
		System.out.println("SpellChecker Object Created");
	}
 
	@Override
	public String checkWord(String word) {
		return "The word in Hindi,  " + word + ", is ok";
	}

}
