package com.nau.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.nau"})
public class MyBeanConfiguration {
	
	
//	@Bean
//	@Lazy
//	public TextEditor getTextEditor() {
//		return new TextEditor();
//	}
//	
}
