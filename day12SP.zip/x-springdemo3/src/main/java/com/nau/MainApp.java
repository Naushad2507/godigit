package com.nau;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.nau.bean.TextEditor;
import com.nau.config.MyBeanConfiguration;

public class MainApp {

	public static void main(String[] args) {

		System.out.println("Start");
		// AbstractApplicationContext applicationContext = new
		// ClassPathXmlApplicationContext("beanno.xml");
		AbstractApplicationContext applicationContext = new AnnotationConfigApplicationContext(
				MyBeanConfiguration.class);

		TextEditor editor = applicationContext.getBean(TextEditor.class);
		String s = editor.spellCheck("naueeee");
		System.out.println(s);
		System.out.println("End"); 
	}

}
