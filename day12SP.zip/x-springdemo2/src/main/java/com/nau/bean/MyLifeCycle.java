package com.nau.bean;

public class MyLifeCycle {
	
	public void globalInit() {
		System.out.println("Global Init Fired");
	}

}
