package com.nau.bean;

public class SpellChecker {
	
	private SpellChecker() {
		System.out.println("SpellChecker Object Created");
	}
	
	public String checkWord(String word) {
		return "The word ,  " + word + ", is ok";
	}

}
