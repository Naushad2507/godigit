package com.nau.bean;

public class TextEditor {

	private SpellChecker spellChecker;

	public TextEditor(SpellChecker spellChecker) { // constructor injection
		super();
		System.out.println("SpellChecker injected by constructor in TextEditor");
		this.spellChecker = spellChecker;
	}

	public void meraInit() {

		System.out.println("I am ready to work");
	}

	public void destroyMe() {
		System.out.println("I am over");
	}

	public TextEditor() {
		System.out.println("TextEditor Object Created");
	}

	public String spellCheck(String word) {
		return spellChecker.checkWord(word);
	}

	public SpellChecker getSpellChecker() {
		return spellChecker;
	}

	public void setSpellChecker(SpellChecker spellChecker) { // settter Injection
		System.out.println("SpellChecker injected by setter in TextEditor");
		this.spellChecker = spellChecker;
	}
}
