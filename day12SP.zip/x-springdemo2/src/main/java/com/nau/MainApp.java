package com.nau;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {

		System.out.println("Start");
		AbstractApplicationContext applicationContext = new ClassPathXmlApplicationContext("beans.xml");
//		applicationContext.registerShutdownHook();
//		TextEditor textEditor = applicationContext.getBean(TextEditor.class);
//		String spell = textEditor.spellCheck("akhtar");
//		System.out.println(spell);
		System.out.println("End");
	}

}
