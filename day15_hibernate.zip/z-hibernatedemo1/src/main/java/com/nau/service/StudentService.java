package com.nau.service;

import org.modelmapper.ModelMapper;

import com.nau.dao.StudentDAO;
import com.nau.entity.StudentEntity;
import com.nau.model.StudentDTO;

public class StudentService {
	
	
	private StudentDAO dao = new StudentDAO();
	
	public void saveStudent(StudentDTO dto) {
		
		ModelMapper mapper = new ModelMapper();
		dto.setName(dto.getName().concat("Mr."));
		StudentEntity studentEntity = mapper.map(dto, StudentEntity.class);
		

//		StudentEntity studentEntity = new StudentEntity(dto.getRollNo(), null, null, null);
		
		
		dao.saveUser(studentEntity);
		
	}
	
	public static void main(String[] args) {

		StudentDTO dto = new StudentDTO(11, "apapa","london","asdf@vv.com"); 
		new StudentService().saveStudent(dto);

	}

}
