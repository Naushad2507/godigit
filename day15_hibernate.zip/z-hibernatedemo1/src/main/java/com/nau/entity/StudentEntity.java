package com.nau.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="godigit")
public class StudentEntity {
	
	@Id
	private Integer rollNo;
	private String name;
	private String city;
	private String email;

}
