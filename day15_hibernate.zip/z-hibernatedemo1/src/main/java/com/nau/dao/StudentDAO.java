package com.nau.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.nau.entity.StudentEntity;
import com.nau.util.HibernateUtil;

public class StudentDAO {
	
	private SessionFactory factory = HibernateUtil.getFactory();

	public void saveUser(StudentEntity studentEntity) {

		
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(studentEntity);
		tx.commit();
		session.close();

	}
	

}
