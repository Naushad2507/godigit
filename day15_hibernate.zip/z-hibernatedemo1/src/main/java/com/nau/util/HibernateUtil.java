package com.nau.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.nau.entity.StudentEntity;

public class HibernateUtil {
	
	private static SessionFactory factory;
	static{
		
		Configuration configuration = new Configuration();
		configuration.addAnnotatedClass(StudentEntity.class);
		configuration.configure();
		factory = configuration.buildSessionFactory();
		
	}
	public static SessionFactory getFactory() {
		return factory;
	}
	

}
