package com.nau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nau.model.UserInfo;
import com.nau.service.LoginService;

@Controller
@RequestMapping("logincontroller")
public class LoginController {

	@Autowired
	private LoginService loginService;

	@PostMapping("verify")
	public ModelAndView verifyUser(UserInfo userInfo) {
		System.out.println(userInfo);
		String message = loginService.verifyUser(userInfo);
		ModelAndView modelAndView = new ModelAndView();
		switch (message) {
		case "unf": {
			modelAndView.addObject("message", "User Not Found");
			modelAndView.setViewName("login");
			return modelAndView;
		}
		case "active": {
			modelAndView.addObject("message", "Welcome + "+userInfo.getUserId());
			modelAndView.setViewName("welcome");
			return modelAndView;
		}
		
		default:
			throw new IllegalArgumentException("Unexpected value: " + message);
		}

		// return modelAndView;
	}
}
