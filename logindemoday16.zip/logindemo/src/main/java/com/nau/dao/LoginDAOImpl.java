package com.nau.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nau.model.UserInfo;
import com.nau.repository.UserInfoRepository;

@Repository
public class LoginDAOImpl implements LoginDAO {

	@Autowired
	private UserInfoRepository userInfoRepository;

	@Override
	public Optional<UserInfo> getUserById(String userId) {

		Optional<UserInfo> optional = userInfoRepository.findById(userId);

		return optional;
	}

}
