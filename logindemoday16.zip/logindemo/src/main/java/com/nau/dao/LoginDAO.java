package com.nau.dao;

import java.util.Optional;

import com.nau.model.UserInfo;

public interface LoginDAO {
	
	public Optional<UserInfo> getUserById(String userId);

}
