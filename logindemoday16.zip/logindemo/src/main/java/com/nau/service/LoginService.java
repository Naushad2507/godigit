package com.nau.service;

import com.nau.model.UserInfo;

public interface LoginService {
	
	public String verifyUser(UserInfo userInfo);
}
