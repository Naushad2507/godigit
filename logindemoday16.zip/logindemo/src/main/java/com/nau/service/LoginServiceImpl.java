package com.nau.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nau.dao.LoginDAO;
import com.nau.model.UserInfo;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDAO loginDAO;
	
	@Override
	public String verifyUser(UserInfo userInfo) {
		String userid = userInfo.getUserId();
		String password = userInfo.getPassword();
		String message ="";
		Optional<UserInfo> fromDB =  loginDAO.getUserById(userid);
		if(fromDB.isEmpty()) {
			System.out.println("unf");
		}else {
			UserInfo ui =	fromDB.get();
			if(ui.getPassword().equals(password)) {
				if(ui.getStatus().equals("active")) {
					message ="welcome";
				}else {
					message = "inactive";
				}
			}else {
				message ="invalidpassword";
			}
		}
		return message;
	}

}
