package com.nau.service;

import java.util.List;

import com.nau.dao.StudentDAO;
import com.nau.dao.StudentDAOImpl;
import com.nau.model.StudentDTO;

public class StudentServiceImpl extends StudentServiceAdaptor{

	private StudentDAO dao ;
 
	public StudentServiceImpl(StudentDAO dao) {
		this.dao = dao;
	}
	
	@Override
	public void addStudents(StudentDTO... dtos) {

		for (StudentDTO dto : dtos) {
			// System.out.println(dto);
			if (dto != null) {
				dto.setName(dto.getName().toUpperCase());
				// System.out.println(dto);
			}
		}

		dao.saveStudent(dtos);
	}

	@Override
	public List<StudentDTO> getAllStudents() {

		return dao.getAllStudents();
	}

	@Override
	public boolean verfifyRollNo(Integer rollNo) {
		return dao.verifyRollNo(rollNo);
	}

}
