package com.nau.service;

import java.util.List;

import com.nau.model.StudentDTO;

public abstract class StudentServiceAdaptor implements StudentService {

	@Override
	public void addStudents(StudentDTO... dtos) {

	}

	@Override
	public List<StudentDTO> getAllStudents() {
		return null;
	}

	@Override
	public boolean verfifyRollNo(Integer rollNo) {
		return false;
	}

	@Override
	public void deleteStudent(Integer rollNo) {

	}

	@Override
	public void updateStudent(StudentDTO dto) {

	}
}
