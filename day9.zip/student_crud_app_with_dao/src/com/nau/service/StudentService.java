package com.nau.service;

import java.util.List;

import com.nau.model.StudentDTO;

public interface StudentService {

	void addStudents(StudentDTO... dtos);

	List<StudentDTO> getAllStudents();

	boolean verfifyRollNo(Integer rollNo);
	
	void deleteStudent(Integer rollNo);
	
	void updateStudent(StudentDTO dto);

}