package training_Day2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) throws IOException {

		String s1 = args[0];
		String s2 = args[1];
		Integer i1 = Integer.parseInt(s1);
		Integer i2 = Integer.parseInt(s2);
		// System.out.println(i1+i2);

		// System.out.println("Enter Number 1");
		// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		// new BufferedReader(new FileReader(new File("")));
		// String n1 = br.readLine();
		// System.out.println("Enter Number 2");
		// String n2 = br.readLine();
		// System.out.println(Integer.parseInt(n1) + Integer.parseInt(n2));
		File file = new File("xyz.txt");
		Scanner scanner = new Scanner(file);
		int total = 10;
		while (scanner.hasNextLine()) {
			Scanner sc = new Scanner(scanner.nextLine());
			while (sc.hasNext()) {
				sc.next();
				if (sc.hasNextInt()) {
					total = total + sc.nextInt();
				}
			}
		}
		System.out.println(total);
//		System.out.println("Enter Number 1 : ");
//		String si1 = scanner.nextLine();
//		System.out.println("Enter Number 2 : ");
//		String si2 = scanner.nextLine();
//		
//		System.out.println(si1 + "\n"+ si2);

	}

}
