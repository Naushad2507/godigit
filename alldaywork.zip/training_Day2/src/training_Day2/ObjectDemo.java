package training_Day2;

class Digit {

	public void digitM() {
		System.out.println("digitM method called");
	}
}

class A1{
	public void a1() {
		System.out.println("a1 called");
	}
}
class B2{
	public void b2() {
		System.out.println("b1 called");
	}
}

public class ObjectDemo {
	public static void main(String[] args) {
		Digit digit = new Digit();
		Object a = new A1();
		
		Object b = new B2();
		
		displayObj(b);
	
	}
	public static void displayObj(Object obj) {
		System.out.println(obj.getClass());
//		if(obj instanceof A1) {
//			A1 marker = (A1)obj;
//			marker.a1();
//		}else {
//			B2 paper = (B2)obj;
//			paper.b2();
//		}
		
		
	}

}
