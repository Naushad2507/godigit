package training_Day2;

import java.util.Objects;


class B{
	
}
class A {

	private String name;
	private String city;

	public A(String name,String city) {
		this.name = name;
		this.city = city;
	}

	@Override
	public int hashCode() {
		return Objects.hash(city, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		A other = (A) obj;
		return Objects.equals(city, other.city) && Objects.equals(name, other.name);
	}
}

public class EqualsDemo {

	public static void main(String[] args) {
		
//		A a = new A("akh","pune");
//		A aa = new A("akh","pune");
//		
//		B b = new B();
//		System.out.println(aa.equals(a));

		String a = new String("hello").intern();
		//String a1 = a.intern();
		String s = "hello";
		String s1 = "world";
		String s2 = "helloworld";
		String s4 = "helloworld";
		String s3 = s + s1;
		System.out.println(a==s);

	}
}
