package training_Day2;

import java.util.Arrays;

public class ArrayDemo {
	public static void main(String[] args) {
		
		int x[] = new int[] {1,4,3,2};
		for(int y : x) {
			System.out.println(y); 
		}
		int a = 10;
		display(x);
		for(int y : x) {
			System.out.println(y);
		}
	}
	
	public static void display(int... x) {
		Arrays.sort(x);
		Arrays.fill(x, 1);
//		int ar = Arrays.binarySearch(x, 4);
//		System.out.println(ar); 
		
//		for (int i = 0; i < x.length; i++) {
//			System.out.println(x[i]);
//		}
//		for(int i : x) {
//			System.out.println(i);
//		}
		//System.out.println(x[3]);
	}
}
