package com.nau;

import java.util.Iterator;

class Demo
{
	private static int a=10;
	int x = 12;
	

 public static int getA() {
   
	 return a;
		
	}


	public static void setA(int a) {
		Demo.a = a;
	}
	
	public int add(int i,int j)	{
		
		for (int j2 = 0; j2 < 10; j2++) {
			
		}
		
		{
			int xx = 3;
			System.out.println("1" );
		}
		{
			System.out.println("2");
		}
		return i+j;
	}


public static void main()
 {
	 
 }
}
