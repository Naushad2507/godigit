package com.nau;

public class MainAppTIC {
	public static void main(String[] args) {
		//ThingsInClass tic1 = new ThingsInClass(7);
		//ThingsInClass tic2 = new ThingsInClass(7);
		int  x = ThingsInClass.count; 
		System.out.println(x);
		int y = ThingsInClass.count;
		System.out.println(y);
//		ThingsInClass.count = 100;  
//		System.out.println(ThingsInClass.count);
//		Employee e1 = new Employee();
//		int age = 2001;
//		e1.setEmp_Age(age);
	}
}
