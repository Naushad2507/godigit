package com.nau;

public class DatatypeDemo {
	
	
	
	public static void main(String... args) {
		
		
		
		var age = 40;
		
		byte a = 122; // 1 byte -128 to 127 
		short b = 122; // 2 byte 
		int c = 10; // 4 byte
		long d = 4586868761L; // 8 byte
		
		byte aa = 122;
		byte ans = (byte)(a+aa);
		System.out.println(ans);
		float e = 12.45F;
		double f = 34.45;
		char g = 'A';
		boolean h = true;
		
		byte ba[] = new byte[1];
		
		int i=1;
		int j=2;
		int k=3;
		
		int x [] = new int[3];
		
		x[2] = 50;
		printLoop(i,x);
		System.out.println(x[2]);
//		int n1 = 40;
//		printValue(n1);
	//	System.out.println(n1);
		String answer = "Yes";
		switch (answer) {
		case "Yes":
			break;
		default:
			break;
		}
	}
	private static void printLoop(int j,int... k) {
		for(int a : k) { 
			System.out.println(a);
		}
		k[2] = 500;
	}
	private static void printValue(int n1) {
		System.out.println("in pv method");
		System.out.println(n1);
		n1 = 600;
		System.out.println("out of pv method");
	}

	

}
