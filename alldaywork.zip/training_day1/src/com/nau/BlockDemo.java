package com.nau;

class A extends Object{
	
	static int count = 10;
	
	{
		System.out.println("init block A " + count);
	}
	static{ 
		System.out.println("static block A " + count);
	}
	public A() {
		super();
		System.out.println("A object created");
	}
}

public class BlockDemo extends A{
	static int count;

	{
		System.out.println("Init block");
	}
	static{
		System.out.println("static block" + count);
	}

	public BlockDemo() {
		super();
		System.out.println("BlockDemo Object created");
	}
	public static void bdm() {
		System.out.println("bdm called");
	}
}
