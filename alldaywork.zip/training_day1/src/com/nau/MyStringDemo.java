package com.nau;

public class MyStringDemo {
	public static void main(String[] args) {
		
		MyString myString = new MyString("naushad");
		System.out.println(myString); 
		System.out.println(myString.changeName("akhtar"));
		System.out.println(myString.changeName("rahul"));
		
		System.out.println(myString); 
	}

}
