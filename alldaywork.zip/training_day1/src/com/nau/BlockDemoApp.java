package com.nau;

public class BlockDemoApp {

	public BlockDemoApp() {
		System.out.println("APP");
	}

	public static void main(String[] args) {

	int x = 0B100001;
	System.out.println(x);
	
	System.out.println("Main");
	new BlockDemo();
	//BlockDemo.bdm();

	}

}
