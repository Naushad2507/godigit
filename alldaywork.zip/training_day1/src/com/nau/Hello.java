package com.nau;

public class Hello {

	int x  =10;
	
	public static void main(String[] args) {
		
		
		Hello h = new Hello();
		h.x = 5;
		
		
	}
	
	
}
