package com.nau;

public class MyString {
	
	
	private final String name;
	
 	public MyString(String name) {
		this.name = name;
	}
	
	public String changeName(String cn) {
		return new String(this.name + cn);  
	}
	
	@Override
	public String toString() {
	
		return this.name;
	}
//	public String getName() {
//		return name;
//	}
//	
	
	
}
