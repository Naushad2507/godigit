package com.nau;

public class Dance {
	
	private int x;
	
	public void salsa(int steps) {
		x  = steps;
		System.out.println("Salsa");
	}
	
	public void breakDance() {
		System.out.println("Break Dance");
	}
	
	public void belly() {
		System.out.println("Belly Dance");
	}

}
