package com.nau;

public class StringDemo {
	public static void main(String[] args) {
		String a= "hello";
		System.out.println(a);
		String na = a.toUpperCase();
		
		System.out.println(a.hashCode() + " " + na.hashCode());
		
		System.out.println(a == na);
		System.out.println(na);
		System.out.println(a);
		String b = "hello";
		System.out.println(a.hashCode() + " "  + b.hashCode() );
		 
		String a1 = new String("hello");
		String b1 = new String("hello");
		System.out.println(a1==a);
		
		int x = 10;
		int y = x;
		
		
		
	}
}
