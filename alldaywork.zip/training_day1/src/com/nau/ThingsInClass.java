package com.nau;

public class ThingsInClass {
	
	private ThingsInClass() {
		
		Math.random();
		
	}
	
	private class A{ }
	
	private  int age ; // instance var
	
	static  int count = 0; 
	 
	static{
		System.out.println("Static block : " + ++count);
	}
	
	{ // initializer block
		System.out.println("start of app");
	}
	public  ThingsInClass(int age) {
		System.out.println("ook " + age);
	}
	public  ThingsInClass(String abc) {
	}
	public void ticM1() {
		System.out.println("tic M1");
	}
	public void ticM1(int i) {
		System.out.println("tic M1 " + i);
	}
	

}
