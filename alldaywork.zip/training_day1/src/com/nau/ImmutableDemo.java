package com.nau;

public class ImmutableDemo {
	
	private final int age;
	
	public ImmutableDemo(int age) {
		this.age = age;
	}
	
	public int addMonthsToAge(int month) {
		return this.age + month;
	}
}
