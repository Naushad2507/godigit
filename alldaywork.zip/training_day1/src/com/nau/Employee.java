package com.nau;

public class Employee {
	private static int count;
	private int emp_age;
	private String emp_name;

	public Employee() {
		System.out.println("Employee Object Created");
	}
	 
	public Employee(int emp_age, String emp_name) {
		this.emp_age = emp_age;
		this.emp_name = emp_name;
		count++;
	}

	public static int getCount() {
		
		return count;
	}

	

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public int getEmp_age() {
		return emp_age;
	}

	public void setEmp_age(int emp_age) {
		Employee.count++;
		this.emp_age = emp_age;
	}

	public static void tp() {
		//System.out.println(emp_name);
	}
	public void deleteEmployee() {
		count--;
	}
	
	@Override
	public String toString() {
		return "Employee [emp_age=" + emp_age + ", emp_name=" + emp_name + "]";
	}
	

}
