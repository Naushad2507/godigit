package com.nau;

public class EmployeeApp extends Object {
	public static void main(String[] args) {

		Employee e1 = new Employee();
		
		double x = Math.random();
	 System.out.println(x);
		System.out.println(Employee.getCount());
		System.out.println(Employee.getCount());
		System.out.println(Employee.getCount());
		System.out.println(Employee.getCount());
//		Employee employee1 = new Employee(12, "naushad");
//		System.out.println(employee1);
//		Employee employee2 = new Employee(14, "akhtar");
//		System.out.println(employee2);
//		employee2.setEmp_age(55);
//		System.out.println(employee2);
//		System.out.println(Employee.getCount());
//		employee2.deleteEmployee();
//		System.out.println(Employee.getCount());
	}
}
