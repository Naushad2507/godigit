package com.nau.view;

import java.util.Scanner;

import com.nau.model.Student;

public class StudentView {

	
	// StudentDTO ,  StudentEntity,  StudentModel
	private Scanner scanner = new Scanner(System.in);
	private Student[] students = new Student[15];
	{
		students[0] = new Student(1, "Naushad", "Goa", "nau@gmial.com");
		students[1] = new Student(2, "Akhtar", "Pune", "akhtar@gmial.com");
		students[2] = new Student(3, "Rahul", "Kerala", "rahul@gmial.com");
		students[3] = new Student(4, "Akshay", "Latur", "akshay@gmial.com");
		students[5] = new Student(5, "Roshan", "Pune", "roshan@gmial.com");
	}

	public StudentView() {
		mainMenu();
	}

	private void mainMenu() {
		System.out.println("----- Main Menu -----");
		System.out.println("1. Add Student");
		System.out.println("2. View Student");
		System.out.println("3. View All Student");
		System.out.println("4. Update Student");
		System.out.println("5. Delete Student");
		System.out.println("6. Exit Application");
		System.out.println("Select Option from Menu : (1 - 6)");
		selectOption();
	}

	private void selectOption() {
		int selectedOption = scanner.nextInt();
		switch (selectedOption) {
		case 1: {
			addStudent();
			System.out.print("\033[H\033[2J");  
		    System.out.flush(); 
			mainMenu();
			break;
		}
		case 2: {
			viewStudent();
			break;
		}
		case 3: {
			viewAllStudent();
			mainMenu();
			break;
		}
		case 4: {
			deleteStudent();
			break;
		}
		case 5: {
			updateStudent();
			break;
		}
		case 6: {
			System.out.println("----------- Thanks For Using the App -----------");
			System.exit(0);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + selectedOption);
		}
	}

	private void updateStudent() {

	}

	private void deleteStudent() {

	}

	private void viewAllStudent() {
		System.out.println("-------- Student Record ----------");
		for (Student student : students) {
			if (student != null) {
				System.out.println(
			student.getRollNo() + "\t" 
			+ student.getName() + "\t" 
			+ student.getCity() + "\t"
			+ student.getEmail()); 
			}
		}
		System.out.println("=====================================");
		

	}

	private void viewStudent() {
		// TODO Auto-generated method stub

	}

	private void addStudent() {
		System.out.println("----- Add Student -----");
		System.out.println("Enter Roll No : ");
		Integer rollNo = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter Name : ");

		String name = scanner.nextLine();
		// scanner.next();
		System.out.println("Enter City : ");

		String city = scanner.nextLine();
		//
		System.out.println("Enter Email : ");

		String email = scanner.nextLine();
		// scanner.next();
		Student student = new Student(rollNo, name, city, email);
		//int studentsArraySize = students.length;
		students[getArrayCount()] = student;
		System.out.println("Do you want to add more (Y/N): ");
		String ans = scanner.next();
		if (ans.equalsIgnoreCase("y")) {
			addStudent();
		}

	}

	public int getArrayCount() {
		int count = 0;
		for (Student student : students) {
			if (student == null) {

			} else {
				count = count + 1;
			}
		}
		return count;
	}

}
