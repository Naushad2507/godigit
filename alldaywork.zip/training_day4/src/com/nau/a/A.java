package com.nau.a;

import com.nau.b.B;

public class A extends B {

	public int age;
	private String name;
	public final float PI = 3.14F;

	public A() {
		super();
		System.out.println("object of A created ");
	}

	public A(int age) {
		B b = new B();
		System.out.println("object of A created with int value age: " + age);
	}

	public A(String name) {
		System.out.println("object of A created with name value : " + name);
	}

	public A(int age, String name) {
		this.name = name;
		this.age = age;
		System.out.println("object of A created with name value : " + name + ", age : " + age);
	}

	protected void methodA() {
		System.out.println("methodA in class A");
	}

//	@Override
//	 protected void methodAA1(int i) {
//		System.out.println("methodAA in class AA with int i : " + i);
//	}
//	@Override
//	public void methodBB(int i) {
//		System.out.println("methodBB in class A with int i : " + i);
//	}

	public void methodAA(int i) {
		methodBB(3);
		System.out.println("methodAA in class A with int i : " + i);
	}

	public int methodAA(int i, String j) {
		System.out.printf("methodAA in class A with %d , %S : ", i, j);
		return 0;
	}

	public int methodAA(String i, int j) {
		System.out.println("methodAA in class A with i : " + i);
		return 0;
	}

	@Override
	public String toString() {
		return "A [age=" + age + ", name=" + name + "]";
	}
}
