package com.nau.a;

public class AA {
	
	public void aa() {
		A a = new A();
		a.methodA();
		
	}
	 void methodAA1(int i) {
		System.out.println("methodAA in class AA with int i : " + i);
	}
}
