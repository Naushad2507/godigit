package com.nau;

class Obj {
	private int i;
	public Obj(int i) {
		this.i = i;
		System.out.println("Obj : " + i);
	}
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Object deleted : " + i);
	}
	
	public String aa(String x) {
		return x; 
	}
}

public class MemoryDemo extends Object{
	public static void main(String[] args) {

		Runtime rt = Runtime.getRuntime();
		System.out.println(rt.totalMemory());

		for (int i = 1; i < 10; i++) {
			Obj o = new Obj(i);
			System.gc();
		}
		System.out.println(rt.totalMemory());
		
		System.out.println(rt.freeMemory());
	}
}
