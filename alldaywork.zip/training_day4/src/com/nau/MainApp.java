package com.nau;

import com.nau.a.A;
import com.nau.b.B;

public class MainApp {

	public static void main(String[] args) {
		
		B b = new A(); 
		
		A a = (A)b;
		b.methodBB(33);
		a.methodBB(45);
		
		b = null;
		a = null;
		
	
	//	a.methodBB(2222);
	//	a.methodBB(1, "asdf");
	//	a.methodAA("asdf", 2);
	
		// A a = new B();
	
	}

}
