package com.nau.b;

import com.nau.a.A;

public class BB extends A{
	
	public BB() {
		super();
	}
	
	public void bb() {
		//A a = new A();
	methodA();
		
	}
	@Override
	protected void methodA() {
		
	}
	

}
