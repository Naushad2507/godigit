package com.nau.b;

public  class B {
	
	public B() {
		System.out.println("object of B created ");
	}
 
	public B(int age) {
		System.out.println("object of B created with int value age: " + age);
	}

	public B(String name) {
		System.out.println("object of B created with name value : " + name);
	}

	protected void methodB() {
		System.out.println("methodB in class B");
	}
	 public final void methodBB(int i) {
		System.out.println("methodBB in class B with int i : " + i);
	}

	public int methodBB(int i, String j) {
		System.out.printf("methodBB in class B with %d , %S : ", i, j);
		return 0;
	}

	public int methodBB(String i, int j) {
		System.out.println("methodBB in class B with i : " + i);
		return 0;
	}


}
