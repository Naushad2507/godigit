package com.nau;

import java.awt.Dimension;
import java.awt.Toolkit;

public class TP {

	public static void main(String[] args) {

		Toolkit t = Toolkit.getDefaultToolkit();
		Dimension d = t.getScreenSize();
		double x = d.getHeight();
		System.out.println(x);
	}

}
