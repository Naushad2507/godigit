package com.nau.app;

import com.nau.a.A;

public class MainApp { 
	
	public static void main(String[] args) {
		
		Object a = new A(2,"Naush");  
	//	new B(11,"nau");
		
		System.out.println();
	} 

}
