package com.nau.a;

public class AA {
	public void aa() {
		//A a = new A(); 
	}
}
