package com.nau.a;

import com.nau.b.B;

public class A extends B {

	private int age;
	private String name;

	private A() {
		super(18);
		// this(18,"Naushad");
		System.out.println("object of A created ");  
	}

	public A(int age) {
		super(age);
		// this(age,"Naushad");
		System.out.println("object of A created with int value age: " + age);
	}

	public A(String name) {
		super(name);
		// this(18,name);
		System.out.println("object of A created with name value : " + name);
	}

	public A(int age, String name) {
		super(34); 
		this.name = name;
		this.age = age;
		System.out.println("object of A created with name value : " + name + ", age : " + age);
	}

	public void methodA() {
		System.out.println("methodA in class A");
	}

	public void methodAA() {
		System.out.println("methodAA in class A");
	}

	@Override
	public String toString() {
		return "A [age=" + age + ", name=" + name + "]";
	}
}
