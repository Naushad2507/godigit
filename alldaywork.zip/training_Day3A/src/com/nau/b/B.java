package com.nau.b;

public class B {
	private int age;
	private String name;

//	public B() {
//	//	this(18,"Naushad"); 
//		System.out.println("object of B created ");
//	}
	
	public B(int age) { 
	//	this(age,"Naushad");
		System.out.println("object of B created with int value age: " + age);
	}
	public B(String name) {
	//	this(18,name);
		System.out.println("object of B created with name value : " + name);
	}
	public B(int age,String name) {
		this.name= name;
		this.age = age;
		System.out.println("object of B created with name value : " + name + ", age : " + age);
	}
	public void methodB() {
		System.out.println("methodB in class B");
	}
	public void methodBB() {
		System.out.println("methodBB in class B");
	}
	@Override
	public String toString() {
		return "B [age=" + age + ", name=" + name + "]"; 
	}
}
