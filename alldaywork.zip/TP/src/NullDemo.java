

class Student{
	String name;
	String city;
}
public class NullDemo {
	
	
	static String s = null;
	
	public static void main(String[] args) {
		
		Student student = new Student();
		String sn = student.name;
		sn.toUpperCase();
		
		
		
	}

}
