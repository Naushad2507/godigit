package com.nau;

public interface Fridge {
	
	void brand();
	void size();
	

}
