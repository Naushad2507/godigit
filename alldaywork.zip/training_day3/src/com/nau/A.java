package com.nau;

class X {

}

class Tp extends X implements A {

	@Override
	public void a1() {

	}

	@Override
	public void cook() {

	}

	
}

@FunctionalInterface
interface FI{
	void fa();
	
	public default void square(int i) {
		
	}
}

public interface A {

	public static final float PI = 3.14F;

	void cook();

	void a1();
	
	private  void aa(int i) {
		System.out.println(Math.sqrt(i));
	}
	
	public default void square(int i) {
		aa(i);
	}
	
	public default void calcA(int i,int j) {
		
		System.out.println("calcA total in A : " + (i+j + 10));
	}
	public default void calcX(int i,int j) {
		System.out.println("calcX total in A : " + (i+j + 10));
	}

}
