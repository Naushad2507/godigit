package com.nau;

abstract class MyHouse extends House {

	public MyHouse() {
		// System.out.println("MyHouse Object");
	}

	@Override
	public void bathroom() {
		System.out.println("MyHouse bathroom , ITailian");
	}

}

interface Slipper {
	void wear();
}

class BataSlipper implements Slipper {
	@Override
	public void wear() {
		System.out.println("Wearing Bata Slipper");
	}
}

class RahulKaGhar extends MyHouse {

	public RahulKaGhar() {
		System.out.println("Rahul ka Ghar");
	}

	@Override
	public void bedroom() {
		System.out.println("Rahul ka King Size Bed");
	}

	public void goToKitchen(Slipper slipper) {
		slipper.wear();
	}

	@Override
	public void kitchen(Fridge fridge) {
		fridge.brand();
		fridge.size();
		System.out.println("Rahul Ka Fridge");
	}
}

class AkshayKaGhar extends MyHouse {

	public AkshayKaGhar() {
		System.out.println("AkshayKaGhar bada Ghar");
	}

	public void goToKitchen(Slipper slipper) {
		slipper.wear();
	}

	@Override
	public void kitchen(Fridge fridge) {
		fridge.brand();
		fridge.size();
		System.out.println("Akshay Ka Fridge");

	}

	@Override
	public void bedroom() {
		System.out.println("Akshay ka King Size Bed");
	}

}

public class HouseDemo {
	public static void main(String[] args) {
		House rahulHouse = new RahulKaGhar();
		Fridge rahulF = new RahulFridge();

		// House akshayHouse = new AkshayKaGhar();

//		MyHouse house = new MyHouse();
//		house.bathroom();
//		house.bedroom();
		DisplayHouse.displayHouse(rahulHouse, rahulF);
	}
}

class RahulFridge implements Fridge {

	@Override
	public void brand() {
		System.out.println("LG by Rahul");
	}

	@Override
	public void size() {
		System.out.println("320 Litre");
	}

}

class DisplayHouse {
	public static void displayHouse(House house, Fridge fridge) {
		house.bedroom();
		house.bathroom();
		house.kitchen(fridge);

	}
}
