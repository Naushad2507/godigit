package com.nau;


class AB implements A,B{

	@Override
	public void cook() {
		System.out.println("cook in AB");
	}

	@Override
	public void a1() {
		System.out.println("a1 in AB");
	}
	@Override
	public void b1() {
	System.out.println("b1 method in AB");	
	}

	@Override
	public void calcX(int i, int j) {
		A.super.calcX(i, j);
		B.super.calcX(2, 4);
	}

}

public class MultipleInheritenceDemo {
	
	public static void main(String[] args) {
		AB ab = new AB();
		ab.a1();
		ab.b1();
		ab.cook();
		ab.calcA(2, 4);
		ab.calcB(4, 6);
		ab.calcX(2, 1);
		
	}

}
