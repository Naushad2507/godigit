package com.nau;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

interface Button {
	void on();

	void off();
}

class TV implements Button {

	public void tvscreen() {
		System.out.println("40 inch Tv");
	}
	
	@Override
	public void on() {
		System.out.println("Tv On");
	}

	@Override
	public void off() {
		System.out.println("Tv Off");
	}

}

class Projector implements Button{
	
	public void projectorscreen() {
		System.out.println("Projctor screen is 120 inches");
	}
	@Override
	public void on() {
		System.out.println("Proejct On");
	}

	@Override
	public void off() {
		System.out.println("Project Off");
	}

}

class XX implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ok XX");
	}
	
}
interface Chapati{
	void eatChapati();
}

class MyChapati implements Chapati{

	@Override
	public void eatChapati() {
		System.out.println("NAN Chapatai");
	}
	
}
interface Rice{
	
}
public class IDemo {

	
	public static void eatFood(Chapati chapati,Rice rice) {
		chapati.eatChapati();
	}
	
	public static void main(String[] args) {
		Chapati chapati = new MyChapati();
		//eatFood(chapati);
		
		ActionListener al = new XX();
		new JButton().addActionListener(al);
		
		
		Button tv = new TV();
	
		Button proj = new Projector();
		

		switchBoard(proj);
	}

	private static void switchBoard(Button button) {
		button.on();
		button.off();
	}

}
