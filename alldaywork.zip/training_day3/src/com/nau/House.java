package com.nau;

public abstract class House {
	public House() {
		// System.out.println("House Object");
	}
	public abstract void kitchen(Fridge fridge) ;
	public void bedroom() {
		System.out.println("Chatai bedroom");
	}
	public abstract void goToKitchen(Slipper slipper);
	public abstract void bathroom();

	public void livingroom() {
		System.out.println("Normal Living");
	}
}
