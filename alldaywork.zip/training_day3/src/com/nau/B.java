package com.nau;

public interface B {
	public static final float PI = 3.1456F;

	void cook();
	void b1();
	
//	public default void calc(int i,int j) {
//		System.out.println("total in B : " + (i+j));
//	}
	
	public default void calcB(int i,int j) {
		System.out.println("calcB total in B : " + (i+j));
	}
	public default void calcX(int i,int j) {
		System.out.println("calcX total in B : " + (i+j));
	}
}
