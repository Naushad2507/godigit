package com.nau.service;

import com.nau.model.UserDTO;

public interface UserService {
	
	public UserDTO addUser(UserDTO userDTO);

}
