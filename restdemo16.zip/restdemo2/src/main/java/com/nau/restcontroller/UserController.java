package com.nau.restcontroller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nau.model.UserDTO;

@RestController //Representational State Transfer
@RequestMapping("user")
//@Slf4j
public class UserController {

	private static final Logger log =
	LoggerFactory.getLogger(UserController.class);

	public UserDTO getUser(Integer userId) {
		return null;
	}

	@PostMapping
	@RequestMapping("adduser")
	public UserDTO addUser(@RequestBody UserDTO user) {
		log.info("UserDTO : " + user);
		log.warn("warn");
		return user;
	}

	@GetMapping
	@RequestMapping("getallusers")
	public List<UserDTO> getAllUsers() {
		log.info("getting all users ");
		return null;
	}

	public UserDTO updateUser(UserDTO user) {
		return null;
	}

	public UserDTO deleteUser(Integer userId) {
		return null;
	}

}
