package com.nau.dao;

import java.util.Optional;

import com.nau.model.UserDTO;

public interface UserDAO {

	public Optional<UserDTO> getUser(Integer empid);
}
