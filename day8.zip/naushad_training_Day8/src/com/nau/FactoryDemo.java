package com.nau;

interface Food {
	public void eat();
}

class Pulao implements Food {
	public Pulao() {
		System.out.println("Pulao Ready");
	}

	@Override
	public void eat() {
		System.out.println("Enjoy Pulao Rice");
	}
}

class NoFood implements Food{
	@Override
	public void eat() {
		System.out.println("No Food Available for your choice : " + "Listof Food Available biryani,pulao");
		
	}
}

class Biryani implements Food {
	static {
		System.out.println("Biryani Getting Ready ");
	}

	public Biryani() {
		System.out.println("Biryani Ready");
	}

	@Override
	public void eat() {
		System.out.println("Enjoy Biryani Rice");
	}
}

class FoodFactory {
	public Food getFood(String foodName) {
		switch (foodName) {
		case "biryani": {

			return new Biryani();
			
		}
		case "pulao": {

			return new Pulao();
		}
		default:
			return new NoFood();
		//	throw new IllegalArgumentException("Unexpected value: " + foodName);
		}
	}
}

//public class FactoryDemo {
//
//	public static void main(String[] args) {
//
//		FoodFactory factory = new FoodFactory();
//		Food food = factory.getFood("biryani");
//		eatFood(food);
//
//	}
//
////	public static void main(String[] args)
////			throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException,
////			SecurityException, IllegalArgumentException, InvocationTargetException {
////
////		String food = args[0];
////		System.out.println(food);
////		Class<?> object = Class.forName(food);
////		Object obj = object.getDeclaredConstructor().newInstance();
////		System.out.println(obj);
////		Food foodObj = (Food) obj;
////		System.out.println("Ready for creation");
////		eatFood(foodObj);
////	}
////
//	private static void eatFood(Food food) {
//		food.eat();
//	}
//
//}
