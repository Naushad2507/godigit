package com.nau.exp.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.nau.exp.ExceptionDemo;

public class ExceptionDemoTest {

	@Test
	public void printNamesTest() {
		
		ExceptionDemo demo = new ExceptionDemo();
		int res = demo.addTwoNumbers(2,9);

		assertNotEquals(8, res);
				
		
	}

}
