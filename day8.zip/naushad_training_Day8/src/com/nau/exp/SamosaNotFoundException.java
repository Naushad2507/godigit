package com.nau.exp;

public class SamosaNotFoundException extends Exception{ 
	
	

}
