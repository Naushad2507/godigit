package com.nau.exp;

public class UseCalculator {
	public static void main(String[] args) {
		
		Calculator calculator = new Calculator();
		int res=0;
		
			try {
				res = calculator.add(10, 200);
			} catch (NumberBelowHundredException e) {
				e.printStackTrace();
			}
		
		System.out.println(res); 
		
	}

}
