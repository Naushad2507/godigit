package com.nau.exp;

public class Calculator {

	public int add(int i, int j) throws NumberBelowHundredException {
		if(i<100) {
			throw new NumberBelowHundredException(i);
		}
		return i + j;
	} 

}
