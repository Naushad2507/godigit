package com.nau.exp;

public class NumberBelowHundredException extends Exception{
	
	public NumberBelowHundredException(int i) {
		super("Number You entered is below hundred :" + i );
	}
	@Override
	public String getMessage() {
		
		return super.getMessage();
	}

}
