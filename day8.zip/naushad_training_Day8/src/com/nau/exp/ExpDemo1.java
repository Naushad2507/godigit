package com.nau.exp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ExpDemo1 {

	public static void main(String[] args) {

		System.out.println("start");

		try {
			 new FileInputStream(args[0]);
			System.out.println("ok");
		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finally ");
		}
		System.out.println("end");
	}

	public static void tp() throws FileNotFoundException {
		throw new FileNotFoundException();
	}
}
