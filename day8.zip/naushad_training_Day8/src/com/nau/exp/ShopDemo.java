package com.nau.exp;

public class ShopDemo {

	public static void main(String[] args) {
		naushad();

	}

	private static void naushad() {
		String snack = "samosa";
		String snacks="";
		try {
			snacks = sameer(10, snack);
		} catch (SamosaNotFoundException e) {
			try {
				System.out.println(snack + " Not Found , Go For Bhajiya");
				snacks = sameer(10, "Bhajiya");
			} catch (SamosaNotFoundException e1) {
				e1.printStackTrace();
			}
		}
		System.out.println("Enjoying " + snacks);
	}

	private static String sameer(int i, String snack) throws SamosaNotFoundException {
		return mukesh(i, snack);
	}

	private static String mukesh(int i, String snack) throws SamosaNotFoundException {
		return pandayji(i, snack);

	}

	private static String pandayji(int i, String snack) throws SamosaNotFoundException {
		return shop(i, snack); 

	}

	private static String shop(int i, String snack) throws SamosaNotFoundException {
		if(snack.equalsIgnoreCase("samosa")) {
			throw new SamosaNotFoundException();
		}else {
			return snack; 
		}
	}

}
