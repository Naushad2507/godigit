package com.nau.exp;

public class ExceptionDemo {
	
	public   int  addTwoNumbers(int i, int j) {
		System.out.println("Start");
	//	String s1 = names[0];
	//	System.out.println(s1);
		System.out.println("End");
		return i+j;
	}
}