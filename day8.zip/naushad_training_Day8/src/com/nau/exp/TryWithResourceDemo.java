package com.nau.exp;

import java.util.Scanner;

class MyConnection implements AutoCloseable {
	public MyConnection() {
		System.out.println("REsource created");
	}

	@Override
	public void close() {
		System.out.println("Closing MyConnection Resource");
	}
}

public class TryWithResourceDemo {
	public static void main(String[] args) {
		
		
		try (MyConnection connection = new MyConnection()) {

		}
		System.out.println("Connection TEst");
		try (Scanner scanner = new Scanner(System.in)) {
			int x = scanner.nextInt();
			int y = scanner.nextInt();
			System.out.println(x / y);
		}
		System.out.println("End");
		tp();
	}
	
	public static void tp() {
		System.out.println("tp");
		tp();
	}
}
