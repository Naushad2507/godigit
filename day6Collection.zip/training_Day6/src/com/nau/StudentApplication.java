package com.nau;

import com.nau.view.StudentManagementView;

public class StudentApplication {
	
	public static void main(String[] args) {
		
		
		new StudentManagementView(); 
		
	} 

}
