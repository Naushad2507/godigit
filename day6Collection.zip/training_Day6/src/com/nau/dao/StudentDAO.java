package com.nau.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.nau.model.StudentDTO;

public class StudentDAO { 
	
	private static List<StudentDTO> studentDTOs = new ArrayList<>();
	private static Map<Integer, StudentDTO> map = new HashMap<>();
	static {
		map.put(1,new StudentDTO(1, "NAUSHAD", "Mumbai", "nau@gmail.com"));
	} 

	public List<String> save(List<StudentDTO> studentDTOs) {
		List<String> list = new ArrayList<>();
		for(StudentDTO dto : studentDTOs) {
			//StudentDAO.studentDTOs.add(dto);
			StudentDTO mapDto =  map.putIfAbsent(dto.getRollNo(), dto);
			Integer count=0;
			if(mapDto!=null) {
				count++;
				list.add(count.toString());
			}
		}
		return list;
	}
	
	public boolean verifyRollNo(Integer rollNo) {
		 StudentDTO dto = map.get(rollNo);
		 if(dto==null) {
			return  true;
		 }
		 return false;
	}
	
	public List<StudentDTO> getAllStudents(){
		Set<Integer> set =  map.keySet();
		for(Integer dto : set ) {
			studentDTOs.add(map.get(dto));
		}
		return studentDTOs;
	}
}
