package com.nau.service;

import java.util.List;

import com.nau.dao.StudentDAO;
import com.nau.model.StudentDTO;

public class StudentService {

	private StudentDAO studentDAO = new StudentDAO();

	public List<String> addStudents(List<StudentDTO> studentDTOs) {
 
		// System.out.println(studentDTOs);
		for (StudentDTO studentDTO : studentDTOs) {
			studentDTO.setName(studentDTO.getName().toUpperCase());
		}
		for (StudentDTO studentDTO : studentDTOs) {
			System.out.println(studentDTO);
		}

		return studentDAO.save(studentDTOs);

	}

	public void deleteStudent() {

	}

	public List<StudentDTO> getAllStudents() {
		return studentDAO.getAllStudents();
	}
 
	public boolean verifyRollNo(Integer rollNo) {
		return studentDAO.verifyRollNo(rollNo);
	}

}
