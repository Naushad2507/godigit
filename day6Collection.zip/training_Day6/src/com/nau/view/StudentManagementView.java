package com.nau.view;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.nau.model.StudentDTO;
import com.nau.service.StudentService;

public class StudentManagementView {
 
	private Scanner scanner = new Scanner(System.in);
	private StudentService studentService = new StudentService();
	
	public StudentManagementView() {
		mainOptions();
	}
  void mainOptions() {
		System.out.println("----- Main Menu -----");
		System.out.println("1. Add Student");
		System.out.println("2. View Student");
		System.out.println("3. View All Student");
		System.out.println("4. Update Student");
		System.out.println("5. Delete Student");
		System.out.println("6. Exit Application");
		System.out.println("Select Option from Menu : (1 - 6)");
		selectOption();
	}

	private void selectOption() {
		int selectedOption = scanner.nextInt();
		switch (selectedOption) {
		case 1: {
			addStudent();
			System.out.print("\033[H\033[2J");
			System.out.flush();
			mainOptions();
			break;
		}
		case 2: {
		//	viewStudent();
			break;
		}
		case 3: {
			viewAllStudent();
			mainOptions();
			break;
		}
		case 4: {
		//	deleteStudent();
			break;
		}
		case 5: {
		//	updateStudent();
			break;
		}
		case 6: {
			System.out.println("----------- Thanks For Using the App -----------");
			System.exit(0);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + selectedOption);
		}
	}

	private void viewAllStudent() {
		
		List<StudentDTO> dtos=  studentService.getAllStudents();
		for(StudentDTO dto : dtos) {
			System.out.println(dto);
		}
	}

	private void addStudent() {
	//	StudentDTO[] dto = new StudentDTO[5];
		List<StudentDTO> studentDTOs = new LinkedList<>();
	//	int count = 0;
		String ans = "N";
		do {
			System.out.println("----- Add Student -----");
			System.out.println("Enter Roll No : ");
			Integer rollNo = scanner.nextInt();
			// verifiy rollNo before going ahead;
			if(!studentService.verifyRollNo(rollNo)) {
				System.out.println("Roll No : " + rollNo + " already Exists");
				return;
			}
			scanner.nextLine();
			System.out.println("Enter Name : ");

			String name = scanner.nextLine();
			System.out.println("Enter City : ");

			String city = scanner.nextLine();
			System.out.println("Enter Email : ");

			String email = scanner.nextLine();
			StudentDTO studentDTO = new StudentDTO(rollNo, name, city, email);
	//		dto[count] = student;
	//		count++;
			studentDTOs.add(studentDTO);
			System.out.println("Do you want to add more (Y/N): ");
			ans = scanner.next();

		} while (ans.equalsIgnoreCase("y"));
		List<String> addedStudents = studentService.addStudents(studentDTOs);
		if(addedStudents.size()>0) {
			//
				System.out.println("Student with rollNo s:" + addedStudents + " not added");
			//}
		}
	}
}
