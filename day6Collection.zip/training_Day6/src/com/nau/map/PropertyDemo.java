package com.nau.map;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

import netscape.javascript.JSObject;

public class PropertyDemo {
	
	public static void main(String[] args) throws IOException {
		
		Properties properties = new Properties();
//	 
//		//System.out.println(properties.put("city", "Pune"));
	//	OutputStream outputStream = new FileOutputStream("users.xml",true);
//		properties.put("xyz", "naudb");
//		properties.put("abc", "urlfodb");
//		properties.storeToXML(outputStream, "Data of User");
	
		FileInputStream inputStream = new FileInputStream("users.xml");
		properties.loadFromXML(inputStream);
		
		System.out.println(properties.getProperty("dbname"));
		System.out.println(properties.getProperty("password"));
		
		
		
	}

}
