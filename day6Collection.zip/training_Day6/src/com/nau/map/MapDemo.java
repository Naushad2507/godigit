package com.nau.map;

import java.util.SortedMap;
import java.util.TreeMap;

import com.nau.model.StudentDTO;

public class MapDemo { 
	
	public static void main(String[] args) {
		
//		Map<Integer, String> map = new HashMap<>();
//		System.out.println(map.put(1, "Naushad")); // null
//		System.out.println(map.put(2, "Akhtar")); // null
//		System.out.println(map.put(2, "Aditi")); // Akhtar
//		 
//		System.out.println(map.get(3));
		SortedMap<StudentDTO, StudentDTO> map2 = new TreeMap<>();
	//	Map<Integer, StudentDTO> map2 = new LinkedHashMap<>();
	//	Map<Integer, StudentDTO> map2 = new HashMap<>();
		map2.put(new StudentDTO(), new StudentDTO(4, "Nau", "pune", "nau@gma.com"));
//		map2.put("a", new StudentDTO(2, "Nau", "pune", "nau@gma.com"));
//		map2.put("b", new StudentDTO(3, "Nau", "pune", "nau@gma.com"));
//		map2.put("d", new StudentDTO(1, "Nau", "pune", "nau@gma.com"));
//		
//		if(map.get(2)==null) {
//			System.out.println(map.put(2, "Akshay")); // 
//		} 
//		System.out.println(map.put(2, "Rahul")); // Aditi
////		
//		System.out.println("============================");
////		
	//
		 
//		Set<String> integers =  map2.keySet();
//		for(String i : integers) {
//			System.out.print(i + "\t");
//			StudentDTO s = map2.get(i);
//			System.out.println(s);
//		} 
//		
	}

}
