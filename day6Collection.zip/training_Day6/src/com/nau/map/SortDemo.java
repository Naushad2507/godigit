package com.nau.map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

class Employee {
	private int id;
	private String name;

	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

//	@Override
//	public int compareTo(Employee o) {
//		
//		return this.id-o.id;
//	}

}

public class SortDemo {
	public static void main(String[] args) {

		Employee e1 = new Employee(1, "naushad");
		Employee e2 = new Employee(2, "akhtar");
		List<Employee> employees = new ArrayList<>();

		employees.add(e2);
		employees.add(e1);
		employees.add(e2);

		ListIterator<Employee> it = employees.listIterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		it.next();
		it.previous();
		
		System.out.println("=============================");
		class SortEmployeesById implements Comparator<Employee> {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getId() - o2.getId();
			}
		}
		class SortEmployeesByName implements Comparator<Employee> {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		}
		for (Employee emp : employees) {
			System.out.println(emp);
		}

		System.out.println("AFter Sorting by id");
		Collections.sort(employees, new SortEmployeesById());

		for (Employee emp : employees) {
			System.out.println(emp);
		}
		System.out.println("AFter Sorting by name");
		Collections.sort(employees, new SortEmployeesByName());
		for (Employee emp : employees) {
			System.out.println(emp);
		}
	}
}
