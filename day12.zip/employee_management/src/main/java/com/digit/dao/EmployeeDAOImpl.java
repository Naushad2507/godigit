package com.digit.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.digit.dto.EmployeeDTO;
import com.digit.util.DBConnection;


@Component
public class EmployeeDAOImpl extends EmployeeDAOAdaptor {

	
	@Autowired
	private DBConnection connection ;

	@Override
	public EmployeeDTO  addEmployee(EmployeeDTO employeeDTO) throws SQLException {
		String sql = "insert into employee values(?,?,?,?,?)";
		try (var ps = connection.getConnection().prepareStatement(sql)) {
			ps.setInt(1, employeeDTO.getId());
			ps.setString(2, employeeDTO.getFName());
			ps.setString(3, employeeDTO.getLName()); 
			ps.setString(4, employeeDTO.getCity());
			ps.setFloat(5, employeeDTO.getSalary());
			int res = ps.executeUpdate();
			if (res > 0) {
				return employeeDTO;
			}
		}
		return null;
	}

	@Override
	public List<EmployeeDTO> getAllEmployee() throws SQLException {
		var  employeeDTOs = new ArrayList<EmployeeDTO>();
		String sql = "select * from employee";
		try(var ps = connection.getConnection().prepareStatement(sql)){
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Integer id = rs.getInt(1);
				String fname = rs.getString(2);
				String lname = rs.getString(3);
				String city = rs.getString(4);
				Float salary = rs.getFloat(5);
				employeeDTOs.add(new EmployeeDTO(id, fname, lname, city, salary));
			}
		}
		return employeeDTOs;
	}

}
