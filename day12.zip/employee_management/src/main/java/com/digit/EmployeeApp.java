package com.digit;

import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.digit.dto.EmployeeDTO;
import com.digit.service.EmployeeService;

public class EmployeeApp {

	public static void main(String[] args) {

		System.out.println("Starting Employee Management Project");

		ApplicationContext context = new AnnotationConfigApplicationContext(MYConfiguration.class);
		EmployeeService service = context.getBean(EmployeeService.class);
		try {
			List<EmployeeDTO> dtos = service.getAllEmployee();
			dtos.forEach((e) -> System.out.println(e));
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
