package com.digit.util;

import java.sql.Connection;

public interface DBConnection {
	public  Connection getConnection() ;
}
