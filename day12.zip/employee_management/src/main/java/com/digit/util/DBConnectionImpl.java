package com.digit.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
@Lazy
public class DBConnectionImpl implements DBConnection {

	private Connection connection;
	
	@PostConstruct
	public void init() {
		Properties properties = new Properties();
		InputStream is = DBConnectionImpl.class.getResourceAsStream("/mydb.properties");
		try {
			properties.load(is);
			String url = properties.getProperty("url");
			String user = properties.getProperty("user");
			String password = properties.getProperty("password");
			connection = DriverManager.getConnection(url, user, password);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("Database Connected");
	}

	

	public Connection getConnection() {
		return connection;
	}

}
