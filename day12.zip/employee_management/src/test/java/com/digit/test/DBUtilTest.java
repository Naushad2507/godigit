package com.digit.test;

public class DBUtilTest {
	
	public static void main(String[] args) {
		
		//DBUtil.getConnection();
		
	}

}
