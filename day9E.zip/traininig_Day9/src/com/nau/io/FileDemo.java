package com.nau.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		String fileName = "abc.txt";
		File file = new File(fileName);
		if (file.exists()) {
//			try(FileInputStream fis = new FileInputStream(file)){
//				int x = 0;
//				while((x=fis.read())!= -1){
//					System.out.print((char)x);
//				}
//			}
//			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {
//				String data = "";
//				while ((data = br.readLine()) != null) {
//					System.out.println(data);
//				}
//			}

			try (FileReader fr = new FileReader(file);FileWriter fw = new FileWriter("copy.txt")) {
				int v = 0;
				while((v=fr.read())!=-1) {
					fw.write(v);
				}
			}
		} else {
			System.out.println("Sorry, No File");
		}

	}

}
