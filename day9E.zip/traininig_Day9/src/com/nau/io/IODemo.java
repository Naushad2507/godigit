package com.nau.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;

public class IODemo {

	public static void main(String[] args) throws IOException {
		
	
		Writer writer;
		// System.out.println("Hello");
		// outputstreamMethod();
		//inputstreamMethod();
	//	readerMethod();
		writerMethod();
	}

	private static void writerMethod() throws IOException {
		OutputStream out = System.out;
		try (Writer writer = new OutputStreamWriter(out)) {
			String name = "Naushad";
//			byte b[] = name.getBytes();
//			outputStream.write(b);
			writer.write(name);
		}
	}

	private static void readerMethod() throws IOException {
		InputStream inputStream = System.in;
		
		Reader reader = new InputStreamReader(inputStream) ;
		int x = 0;
		while((x = reader.read() ) != 13) {
			System.out.println((char)x);
		}
		
	}

	private static void inputstreamMethod() throws IOException {
		InputStream inputStream = System.in;
		// byte b[] = new byte[10000];
		int x = 0;
		while((x = inputStream.read() ) != 13) {
			System.out.print((char)x);
		}
		

		//System.out.println((char) x);

	}

	private static void outputstreamMethod() {

		try (PrintStream outputStream = System.out) {
			String name = "Naushad";
//			byte b[] = name.getBytes();
//			outputStream.write(b);
			outputStream.println(name);
		}
		// System.out.println("HELLO");

		// outputStream.flush();
		// outputStream.close();

	}

}
