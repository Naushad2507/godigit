package traininig_Day9;


interface Calculator {
	int doCalc(int i, int j);
}
@FunctionalInterface
interface LDemo {
	int factorial(int i);
}
@FunctionalInterface
interface LDemo1 {
	void factorial();
}


class MyCalculatorPlus implements Calculator {
	@Override
	public int doCalc(int i, int j) {
		return i + j;
	}
}

public class LambdaDemo {
	private static class MyInnerCalculatorPlus implements Calculator {
		@Override
		public int doCalc(int i, int j) {
			return i + j;
		}
	}

	public static void main(String[] args) {
		class MyLocalCalculatorPlus implements Calculator {
			@Override
			public int doCalc(int i, int j) {
				return i + j;
			}
		}

		Calculator calculator = new Calculator() {
			@Override
			public int doCalc(int i, int j) {
				return i + j;
			}
		};
		// Calculator calculatorPlus = new MyLocalCalculatorPlus();
		// calculate(calculatorPlus);//
		// calculate(calculator);

//		calculate(new Calculator() {
//			@Override
//			public int doCalc(int i, int j) {
//				return i+j;
//			};
//		});

		Calculator mul = (int i, int j) -> {
			return i * j;
		};
		Calculator mul2 = (i, j) -> {
			return i * j;
		};
		Calculator mul3 = (i, j) ->  {int k = i*10 ; return k * j; };
		
		//calculate(mul3);
		
		calculate((i,j)->i/j);
		
		LDemo demo = x->   x*x  ;
		LDemo1 demo1 = ()->   System.out.println("Hellooooooo");  ;
		
		factorial(demo1);

	}
	private static void factorial(LDemo1 demo) {
		demo.factorial();
	//	System.out.println(res);

	}
	private static void calculate(Calculator calculator) {
		int res = calculator.doCalc(200, 110);
		System.out.println(res);

	}

}








