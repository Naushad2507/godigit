package traininig_Day9;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
class Employee {
	private int id;
	private String name;
}

public class LambdaDemo2 {

	public static void main(String[] args) {
		
		

		Employee e1 = new Employee(4, "nau1");
		Employee e2 = new Employee(2, "nau2");
		Employee e3 = new Employee(1, "nau3");
		Employee e4 = new Employee(5, "nau3");
		Employee e5 = new Employee(3, "nau3");
		Employee e[] = { e3, e1, e2, e4, e5 };

		List<Employee> elist = Arrays.asList(e);
		
		
		//elist.parallelStream();
		elist.forEach(System.out::println);
		Collections.sort(elist, (ee1, ee2) -> ee1.getName().compareTo(ee2.getName()));
		elist.forEach(System.out::println);

		Predicate<Employee> em = new Predicate<>() {
			@Override
			public boolean test(Employee t) {
				return t.getId() > 2;
			}
		};
		System.out.println("=========FILTER===================");
		int x1 = Runtime.getRuntime().availableProcessors();
		System.out.println(x1);
		elist.parallelStream()
		.filter(emp -> emp.getId() < 4)
		.sorted((ea1, ea2) -> ea1.getId() - ea2.getId())
		.forEach(System.out::println);
		
		System.out.println("==========End Filter============");
		// elist.forEach(System.out::println);
		// System.out.println(e1);

		String names[] = { "nau", "akh", "rahu" };

		List<String> nameList = Arrays.asList(names);

		Consumer<String> consumer = new Consumer<String>() {

			@Override
			public void accept(String t) {

				System.out.println(t);
			}
		};

		Consumer<String> consumer2 = x -> System.out.println(x);

		nameList.forEach(System.out::println);
		Collections.sort(nameList);

	}

}
