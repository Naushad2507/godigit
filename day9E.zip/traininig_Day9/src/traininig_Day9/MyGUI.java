package traininig_Day9;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

class TP extends WindowAdapter{

	
	@Override
	public void windowClosing(WindowEvent e) {
		System.out.println("window closing");
		System.exit(0);
	}

}

public class MyGUI {
	
	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		
		
		frame.setSize(200, 200);
		frame.setVisible(true);
		TP tp = new TP();
		frame.addWindowListener(tp);
		
	}

}
