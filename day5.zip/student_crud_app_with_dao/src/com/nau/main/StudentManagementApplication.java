package com.nau.main;

import com.nau.view.StudentView;

public class StudentManagementApplication {
	
	public static void main(String[] args) {
		
		new StudentView();
		
	}
}
