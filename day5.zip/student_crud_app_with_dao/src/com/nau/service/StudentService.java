package com.nau.service;

import com.nau.dao.StudentDAO;
import com.nau.model.StudentDTO;

public class StudentService {

	private StudentDAO dao = new StudentDAO();

	public void addStudents(StudentDTO... dtos) {

		for (StudentDTO dto : dtos) {
		//	System.out.println(dto);
			if (dto != null) {
				dto.setName(dto.getName().toUpperCase());
			//	System.out.println(dto);
			}
		}
		
		dao.saveStudent(dtos);
	}

	public StudentDTO[] getAllStudents() {
		
		return dao.getAllStudents();
	}
	
	

}
