package com.nau.dao;

import com.nau.model.StudentDTO;

public class StudentDAO {
	
	private static int count=4;
	private StudentDTO[] students = new StudentDTO[15];
	{
		students[0] = new StudentDTO(1, "Naushad", "Goa", "nau@gmial.com");
		students[1] = new StudentDTO(2, "Akhtar", "Pune", "akhtar@gmial.com");
		students[2] = new StudentDTO(3, "Rahul", "Kerala", "rahul@gmial.com");
		students[3] = new StudentDTO(4, "Akshay", "Latur", "akshay@gmial.com");
		students[4] = new StudentDTO(5, "Roshan", "Pune", "roshan@gmial.com");
	}
	
	public void saveStudent(StudentDTO... studentDTOs) {
		
		for(StudentDTO dto : studentDTOs) {
			System.out.println("DAO");
			System.out.println(dto);
			if(studentDTOs!=null) {
				count++;
				students[count] = dto;
			}
		}
		System.out.println("Total : " + (count-4) + " saved");
	}
	
	public StudentDTO[] getAllStudents() {
		
		
		
		return students; 
	}
}
