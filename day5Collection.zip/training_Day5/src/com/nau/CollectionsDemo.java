package com.nau;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Vector;

public class CollectionsDemo {

	class XX {
	}

	public static void main(String[] args) {

		// arrayListDemo();
		// vectorDemo();
		// setDemo();
		// setDemoEmployee();
		//sortDemo();
		sortedSetDemo();
	}

	private static void sortedSetDemo() {
		Employee employee1 = new Employee(1, "naushad");
		Comparator<Employee> byName = new Comparator<Employee>() {
			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		};
		SortedSet<Employee> emps = new TreeSet<>(byName);
		System.out.println(emps.add(new Employee(4, "akh")));
		System.out.println(emps.add(employee1));
		System.out.println(emps.add(new Employee(3, "akh")));
		System.out.println(emps.add(new Employee(2, "naushad")));

		for (Employee emp : emps) {
			System.out.println(emp);
		}
		
	}

	private static void sortDemo() {
		Employee employee1 = new Employee(1, "naushad");
		Set<Employee> emps = new HashSet<>();
		System.out.println(emps.add(new Employee(4, "akh")));
		System.out.println(emps.add(employee1));
		System.out.println(emps.add(new Employee(3, "akh")));
		System.out.println(emps.add(new Employee(2, "naushad")));

		for (Employee emp : emps) {
			System.out.println(emp);
		}
		List<Employee> empList = new ArrayList<>(emps);
		Comparator< Employee> byName = new Comparator<Employee>() {
			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		};
		Collections.sort(empList,byName);
	}
	private static void setDemoEmployee() {
		Employee employee1 = new Employee(1, "naushad");
		Set<Employee> emps = new HashSet<>();
		System.out.println(emps.add(employee1));
		System.out.println(emps.add(new Employee(1, "akh")));
		System.out.println(emps.add(new Employee(2, "naushad")));

		for (Employee emp : emps) {
			System.out.println(emp);
		}
	}

	private static void setDemo() {
		Set<String> names = new HashSet<>();
		names.add("nau");
		names.add("abc");
		names.add("abc");
		names.add("dfdf");
		names.add("aaa");

		for (String s : names) {
			System.out.println(s);
		}

	}

	private static void vectorDemo() {
		Vector<String> vector = new Vector<>(20, 2);

	}

	private static void arrayListDemo() {

		// ArrayList<String> names = new ArrayList<>();
		List<String> names1 = new ArrayList<>();
		Collection<String> names2 = new ArrayList<>();

//		ArrayList names = new ArrayList();
//		names.add("naushad");
//		names.add("akhtar");
//		
//		Object o = names.get(0);
//		String s = (String)o;
//		String uc = s.toUpperCase();
//		System.out.println(uc);
		ArrayList<Integer> numbers = new ArrayList<>();
		numbers.ensureCapacity(0);

		numbers.add(5);
		numbers.add(3);
		numbers.add(1);

		System.out.println(numbers);
		numbers.remove(Integer.valueOf(5));
		System.out.println(numbers);
		ArrayList<String> names = new ArrayList();
		names.add("baba");
		names.add("kaka");
		names.add("naushad");
		names.add("akhtar");

//		String n = names.get(0).toUpperCase();
//		System.out.println(n);

		names.add(1, "rahul");

		class NamesSort implements Comparator<String> {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		}
		NamesSort ns = new NamesSort();
		Comparator<String> namescomparator = new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		};

		Collections.sort(names);

//		names.sort(new Comparator<String>() {
//			@Override
//			public int compare(String o1, String o2) {
//				return o1.compareTo(o2);
//			}
//		});

		Iterator<String> it = names.iterator();

		while (it.hasNext()) {
			System.out.println(it.next());
		}

		// names.remove("rahul");

		for (int i = 0; i < names.size(); i++) {
			System.out.println(names.get(i));
		}
		for (String s : names) {
			System.out.println(s.toUpperCase());
		}

		ListIterator<String> literator = names.listIterator();
		literator.hasPrevious();

	}

}
