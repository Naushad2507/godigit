package com.nau;

import java.util.ArrayList;
import java.util.List;

public class StreamDemo {
	
	public static void main(String[] args) {
		
		List<String> l = new ArrayList<>();
		l.add("ad");
		l.add("gg");
		
		l.stream().forEach((x)->System.out.println(x));
		
		l.forEach((x)->System.out.println(x));
		
		for(String ll : l) {
			System.out.println(ll);
		}
		
		
	}

}
