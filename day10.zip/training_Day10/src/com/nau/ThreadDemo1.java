package com.nau;

public class ThreadDemo1 {

	public static void main(String[] args) throws InterruptedException {

		Thread t = Thread.currentThread();
		System.out.println(t.getId());
		System.out.println(t.getName());
//		System.out.println(t.getContextClassLoader());
//		System.out.println(t.getState());
//		System.out.println(t.getThreadGroup());
		System.out.println("start");

		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				
				for (int j = 0; j < 100; j++) {
					Thread t = Thread.currentThread();
					System.out.println(t.getId());
					System.out.println(t.getName());
					System.out.println("j = " + j);
				}
			}
		};
		
		Thread.sleep(5000);
		
		new Thread(runnable,"nau1").start();
		; // new
		// t1.setDaemon(false);
		// t1.start();

		new Thread(() -> {
			for (int i = 0; i < 100; i++) {
				Thread t1 = Thread.currentThread();
				System.out.println(t1.getId());
				System.out.println(t1.getName());
				System.out.println("i = " + i);
			}
		},"nau2").start();

		System.out.println("end");
	}

}
