package com.nau;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GUI extends JFrame {

	private JButton b1, b2;
	private JTextField jtf1, jtf2;
	private JTextArea jta1, jta2;
	private JPanel jp1, jp2, jp3, jp4;

	public GUI() {

		createUI();
		createEvents();
		setSize(300, 500);
		setVisible(true);
	}

	private void createEvents() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		b1.addActionListener((e)->{
			new Thread(()->{
				for(int i=1;i<20;i++) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					jta1.append("2 * " + i + " = " + (2*i) + "\n");
				}
			}).start();
		});
		b2.addActionListener((e)->{
			new Thread(()->{
				for(int i=1;i<20;i++) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					jta2.append("4 * " + i + " = " + (4*i) + "\n");
				}
			}).start();
		});
	}

	private void createUI() {
		jp1 = new JPanel(new GridLayout(1, 2));
		b1 = new JButton("Print");
		b2 = new JButton("Button 2");
		jp1.add(b1);
		jp1.add(b2);
		add(jp1, BorderLayout.NORTH);
		
		jp2 = new JPanel(new GridLayout(1, 2));
		jta1 = new JTextArea();
		jta2 = new JTextArea();
		jp2.add(jta1);
		jp2.add(jta2);
		add(jp2);

	}

}
