package com.nau.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCDemo {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		System.out.println("start");
		
		
		//Class.forName("org.postgresql.Driver");
		String url = "jdbc:postgresql:naushad";
		String username = "postgres";
		String password="naushad";
		
		Connection connection = DriverManager.getConnection(url, username, password);
		System.out.println("Connected");

		String sql = "insert into users  (username) values(?)";
		
		PreparedStatement ps = connection.prepareStatement(sql);
		//ps.setInt(1,12);
		ps.setString(1,"Naushad");
		ps.executeUpdate();
		
		System.out.println("Data Inserted");

		
				
	}

}
