package com.nau;

public class ThreadTable {
	
	public static void main(String[] args) {
		new GUI();
	}

}
