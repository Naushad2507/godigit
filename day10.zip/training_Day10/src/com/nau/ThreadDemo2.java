package com.nau;

class Printer {
	public synchronized void print(String data) {
		//Lock
		byte b[] = data.getBytes();
		for (byte bb : b) {
			System.out.println(Thread.currentThread().getName());
			System.out.println((char) bb);
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}

public class ThreadDemo2 {

	public static void main(String[] args) {
		Printer printer = new Printer();
		Thread p1 = new Thread(() -> {
			printer.print("AAAA AAAA 1");
		});
		p1.start();
		Thread p2 = new Thread(() -> {
			printer.print("BBBB BBBB 2");
		});
		p2.start();
		Thread p3 = new Thread(() -> {
			printer.print("CCCC CCCC 3");
		});
		p3.start();

	}

}
