package com.nau.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nau.entity.StudentEntity;
import com.nau.repository.StudentRepository;


@Repository
public class StudentDAOImpl implements StudentDAO {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public StudentEntity saveStudent(StudentEntity studentEntity) {
		StudentEntity entity = studentRepository.save(studentEntity);
		
		return entity;
	}
}
