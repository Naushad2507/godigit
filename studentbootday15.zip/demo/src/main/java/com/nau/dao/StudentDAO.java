package com.nau.dao;

import com.nau.entity.StudentEntity;

public interface StudentDAO {
	
	public StudentEntity saveStudent(StudentEntity studentEntity) ;

}
