package com.nau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nau.dao.StudentDAO;
import com.nau.entity.StudentEntity;

@Controller
@RequestMapping("student")
public class StudentController {
	
	@Autowired
	private StudentDAO studentDAO;
	
	@PostMapping("save")
	public String saveStudent(StudentEntity studentEntity) {
		System.out.println(studentEntity);
		studentDAO.saveStudent(studentEntity);
		
		return "";
	}

}
