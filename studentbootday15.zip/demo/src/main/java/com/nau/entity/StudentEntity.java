package com.nau.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "godigit")
public class StudentEntity {
	
	@Id
	private Integer rollno;
	
	private String uname;
	private String ucity;
	private String uemail;

}
