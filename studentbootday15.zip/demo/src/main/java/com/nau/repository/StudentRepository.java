package com.nau.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nau.entity.StudentEntity;

public interface StudentRepository extends JpaRepository<StudentEntity, Integer>{
	
	public  Optional<StudentEntity> findByName(String name);

}
