package com.digit.service;

import java.sql.SQLException;
import java.util.List;

import com.digit.dto.EmployeeDTO;

public interface EmployeeService {
	EmployeeDTO addEmployee(EmployeeDTO employeeDTO) throws SQLException;

	EmployeeDTO updateEmployee(EmployeeDTO employeeDTO)throws SQLException;;

	Integer deleteEmployee(Integer empId)throws SQLException;;
	
	EmployeeDTO getById(Integer id)throws SQLException;;
	
	List<EmployeeDTO> getAllEmployee()throws SQLException;;
	
	List<EmployeeDTO> getByCity(String city)throws SQLException;;
	
	List<EmployeeDTO> getBySalary(Float salary)throws SQLException;;
}
