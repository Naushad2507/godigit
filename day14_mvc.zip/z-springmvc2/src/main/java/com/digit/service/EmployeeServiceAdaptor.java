package com.digit.service;

import java.sql.SQLException;
import java.util.List;

import com.digit.dto.EmployeeDTO;

public abstract class EmployeeServiceAdaptor implements EmployeeService {

	@Override
	public EmployeeDTO addEmployee(EmployeeDTO employeeDTO) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO employeeDTO) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer deleteEmployee(Integer empId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeDTO getById(Integer id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeDTO> getAllEmployee() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeDTO> getByCity(String city) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeDTO> getBySalary(Float salary) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
