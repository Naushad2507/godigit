package com.digit.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.digit.dao.EmployeeDAO;
import com.digit.dto.EmployeeDTO;

@Component
public class EmployeeServiceImpl extends EmployeeServiceAdaptor{
	
	@Autowired
	private EmployeeDAO employeeDAO;
	
	@Override
	public EmployeeDTO addEmployee(EmployeeDTO employeeDTO) throws SQLException {
		
		return employeeDAO.addEmployee(employeeDTO);
	}
	
	@Override
	public List<EmployeeDTO> getAllEmployee() throws SQLException {
	
		return employeeDAO.getAllEmployee();
		
	}

}
