package com.digit.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.digit.dto.EmployeeDTO;


@Component
public class EmployeeDAOImpl extends EmployeeDAOAdaptor {
	
	@Autowired
	private JdbcTemplate jdbcTemplate ;

	@Override
	public EmployeeDTO  addEmployee(EmployeeDTO employeeDTO) throws SQLException {
		
		String sql = "insert into employee values(?,?,?,?,?)";
		 jdbcTemplate.update(sql, 
				employeeDTO.getId(),
				employeeDTO.getFName(),
				employeeDTO.getLName(),
				employeeDTO.getCity(),
				employeeDTO.getSalary()
				);
		return 	employeeDTO;
	}

	@Override
	public List<EmployeeDTO> getAllEmployee() throws SQLException {
		String sql = "select * from employee";
		List<EmployeeDTO> employeeDTOs = jdbcTemplate.
				query(sql,new BeanPropertyRowMapper<EmployeeDTO>(EmployeeDTO.class));
				return employeeDTOs;
	}

}
