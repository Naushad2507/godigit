package com.digit.dao;

import java.sql.SQLException;
import java.util.List;

import com.digit.dto.EmployeeDTO;

public abstract class EmployeeDAOAdaptor implements EmployeeDAO{

	@Override
	public EmployeeDTO addEmployee(EmployeeDTO employeeDTO) throws SQLException {
		return null;
	}

	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO employeeDTO) {
		return null;
	}

	@Override
	public Integer deleteEmployee(Integer empId) {
		return null;
	}

	@Override
	public EmployeeDTO getById(Integer id) {
		return null;
	}

	@Override
	public List<EmployeeDTO> getAllEmployee() throws SQLException {
		return null;
	}

	@Override
	public List<EmployeeDTO> getByCity(String city) {
		return null;
	}

	@Override
	public List<EmployeeDTO> getBySalary(Float salary) {
		return null;
	}

}
